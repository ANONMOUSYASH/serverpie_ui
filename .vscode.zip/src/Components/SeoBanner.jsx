import React from 'react'
import '../Styles/SeoBanner.css'

const SeoBanner = () => {
  return (
    <div className='seobanner'>
        <div className="seobanner1">
            <div className="seobannermini1">
                <p className='seobannerminipar1'>THE ALL-NEW, BLAZING FAST</p>
                <p className='seobannerminipar2'>India Server Location</p>
                <p className='seobannerminipar3'>Boost conversions and SEO ranking by reducing your website load-time!</p>
                <p className='seobannerminipar3'>Start by selecting a server location that is closest to your customer. If most</p>
                <p className='seobannerminipar3'>of your customers reside in India, you should pick a data center located in</p>
                <p className='seobannerminipar3'>or close to India for faster website load time.</p>
            </div>
            <div className="seobannermini2"></div>
        </div>
    </div>
  )
}

export default SeoBanner;