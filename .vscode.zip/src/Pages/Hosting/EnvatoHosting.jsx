import React from 'react'
import Navbar from '../../Components/Navbar';
import Footer from '../../Components/Footer';

const EnvatoHosting = () => {
  return (
    <div>
    <nav>
      {/* <Navbar /> */}
    </nav>
    <main></main>
    <footer>
      <Footer />
    </footer>
  </div>
  )
}

export default EnvatoHosting;
