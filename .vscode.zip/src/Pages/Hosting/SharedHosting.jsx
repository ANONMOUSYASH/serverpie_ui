import React from 'react'
import Navbar from '../../Components/Navbar';
import Footer from '../../Components/Footer';
import HostingSolution from '../../Components/HostingSolution';

const SharedHosting = () => {
  return (
    <div>
    <nav>
      {/* <Navbar /> */}
    </nav>
    <main>
        <HostingSolution />
    </main>
    <footer>
      <Footer />
    </footer>
  </div>
  )
}

export default SharedHosting;
