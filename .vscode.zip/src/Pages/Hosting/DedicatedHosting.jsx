import React from 'react'
import Navbar from '../../Components/Navbar';
import Footer from '../../Components/Footer';

const DedicatedHosting = () => {
  return (
    <div>
    <nav>
      {/* <Navbar /> */}
    </nav>
    <main></main>
    <footer>
      <Footer />
    </footer>
  </div>
  )
}

export default DedicatedHosting;
