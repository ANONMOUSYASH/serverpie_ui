import React from 'react'
import Navbar from '../../Components/Navbar';
import Footer from '../../Components/Footer';
import Attacks from '../../Components/Attacks';
import Migration from '../../Components/Migration';
import DdosAttacks from '../../Components/DdosAttacks';

const DomainReg = () => {
  return (
    <div>
      <nav>
        {/* <Navbar /> */}
      </nav>
      <main>
        <Attacks />
        <Migration />
        <DdosAttacks />
      </main>
      <footer>
        <Footer />
      </footer>
    </div>
  )
}
export default DomainReg;
