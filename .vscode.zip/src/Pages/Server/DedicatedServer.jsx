import React from 'react'
import Navbar from '../../Components/Navbar';
import Footer from '../../Components/Footer';

const DedicatedServer = () => {
  return (
    <div>
      <nav>
        {/* <Navbar /> */}
      </nav>
      <main></main>
      <footer>
        <Footer />
      </footer>
    </div>
  )
}

export default DedicatedServer;
