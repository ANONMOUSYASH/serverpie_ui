import React from 'react'
import Navbar from '../../Components/Navbar';
import Footer from '../../Components/Footer';

const WindowServer = () => {
  return (
    <div>
   
    <main></main>
    <footer>
      <Footer />
    </footer>
  </div>
  )
}

export default WindowServer;
