import Footer from "../Components/Footer";
import Navbar from "../Components/Navbar";
import { CiSearch } from "react-icons/ci";
import { IoEarthSharp } from "react-icons/io5";
import { FaPlus } from "react-icons/fa6";
import { RiSubtractFill } from "react-icons/ri";
import { TbSquareRoundedArrowRightFilled } from "react-icons/tb";
import { PiChatCircleTextFill } from "react-icons/pi";
import { FaPhoneVolume } from "react-icons/fa6";
import { PiChatsCircleFill } from "react-icons/pi";
// import { IoMdStar } from "react-icons/io";

import "../Styles/Home.css";
import Testimonial from "../Components/Testimonial";

const Home = () => {
  return (
    <div>
      <main>
        <div className="hero">
          <p className="heropar1">India's Leading Hosting Provider</p>
          <p className="herohead1">
            Your Dream <span className="herohd">Domain</span> Awaits{" "}
            <span className="herohs">Start Today</span>
            <span className="herohe">!</span>
          </p>
          <p className="heropar2">
            Launch your website today with a domain that works for you!
          </p>

          <div className="heroinput">
            <div className="input-container">
              <CiSearch className="herosearch" />
              <input
                className="heroinput1"
                type="text"
                placeholder="Enter Your Domain Name"
              />
            </div>
            <hr className="herohr" />
            <div className="select-container">
              <IoEarthSharp className="heroearth" />
              <select className="heroselect">
                <option value="com">Domain</option>
                <option value="net">.com</option>
                <option value="net">.net</option>
                <option value="org">.org</option>
                <option value="in">.in</option>
              </select>
            </div>
          </div>
          <button className="herobtn">Find My Domain</button>
        </div>
        <div className="herorec">
          {/* <div className="subrec">
            <h2 className="subrechead">
              Discover Our Advanced Anti-DDoS Solutions
            </h2>
            <p className="subrecpar">
              Our platform is fully equipped with the features you’ll need so
              you never have to worry about speed, security, and support for
              your websites, boost your digital experience with us.
            </p>
          </div> */}
        </div>
        <div className="heroheadmain2">
          <p className="herohead2">
            From Peak Performance To Non-stop Support, We’ve Got Every Angle
            Covered.
          </p>
          <div className="herorec2">
            <div className="herorec3">
              <h3 className="herohead4">Performance</h3>
            </div>
            <h3 className="herohead5">Security</h3>
            <h3 className="herohead5">Flexibility</h3>
            <h3 className="herohead5">Scalability</h3>
            <h3 className="herohead5">Support</h3>
          </div>
          <div className="heromainbox">
            <div className="herobox1">
              <div className="herosubbox1">
                <div className="herosubearth1">
                  <IoEarthSharp className="herosubearth2" />
                </div>
                <h4 className="heroboxhead1">Rapid Deployment</h4>
                <p className="heroboxpar1">
                  Deploy your server in just minutes with our streamlined
                  process, ensuring your projects launch quickly.
                </p>
              </div>
            </div>
            <div className="herobox2">
              <div className="herosubbox1">
                <div className="herosubearth1">
                  <IoEarthSharp className="herosubearth2" />
                </div>
                <h4 className="heroboxhead2">Rapid Deployment</h4>
                <p className="heroboxpar2">
                  Deploy your server in just minutes with our streamlined
                  process, ensuring your projects launch quickly.
                </p>
              </div>
            </div>
            <div className="herobox3">
              <div className="herosubbox1">
                <div className="herosubearth1">
                  <IoEarthSharp className="herosubearth2" />
                </div>
                <h4 className="heroboxhead1">Rapid Deployment</h4>
                <p className="heroboxpar1">
                  Deploy your server in just minutes with our streamlined
                  process, ensuring your projects launch quickly.
                </p>
              </div>
            </div>
          </div>
        </div>
        <div className="framemain">
          <div className="framesub1">
            <p className="framesubpar1">
              Tailored Cloud Services for{" "}
              <span className="framsubspan">Every Need</span>
            </p>
            <p className="framesubpar2">
              Our platform is fully equipped with the features you’ll need so
              you never have to worry about speed, security, and support for
              your websites, boost your digital experience with us.
            </p>
            <div className="framesubmainbtn">
              <button className="framesubbtn1">Hosting</button>
              <button className="framesubbtn2">Servers</button>
              <button className="framesubbtn3">Security</button>
            </div>
          </div>
          <div className="">
            <div className="container">
              <div className="row d-flex align-items-center justify-content-center min-vh-100 card-container-bg">
                <div className="col-lg-4">
                        <div className="card">
                          <div className="card-icon">
                            <IoEarthSharp className="icon" />
                          </div>
                          <h4 className="card-title">Shared Hosting</h4>
                          <p className="card3-description">
                            The Perfect Hosting Solution for Bloggers, Small Businesses, and
                            Personal Websites – Offering Fast, Secure, Reliable, and
                            Affordable Performance to Help You Grow Online
                          </p>
                        </div>
                </div>
                <div className="col-lg-4">
                        <div className="card">
                          <div className="card-icon">
                            <IoEarthSharp className="icon" />
                          </div>
                          <h4 className="card-title">Shared Hosting</h4>
                          <p className="card3-description">
                            The Perfect Hosting Solution for Bloggers, Small Businesses, and
                            Personal Websites – Offering Fast, Secure, Reliable, and
                            Affordable Performance to Help You Grow Online
                          </p>
                        </div>
                        <div className="card mt-4">
                          <div className="card-icon">
                            <IoEarthSharp className="icon" />
                          </div>
                          <h4 className="card-title">Shared Hosting</h4>
                          <p className="card3-description">
                            The Perfect Hosting Solution for Bloggers, Small Businesses, and
                            Personal Websites – Offering Fast, Secure, Reliable, and
                            Affordable Performance to Help You Grow Online
                          </p>
                        </div>
                        
                </div>
                <div className="col-lg-4">
                          <div className="card">
                            <div className="card-icon">
                              <IoEarthSharp className="icon" />
                            </div>
                            <h4 className="card-title">Shared Hosting</h4>
                            <p className="card3-description">
                              The Perfect Hosting Solution for Bloggers, Small Businesses, and
                              Personal Websites – Offering Fast, Secure, Reliable, and
                              Affordable Performance to Help You Grow Online
                            </p>
                          </div>
                         
                </div>
              </div>
            </div>
          </div>
          <div className="framemain2">
            <div className="framechild2">
              <p className="framechildpar1">
                Discover Our Advanced Anti-DDoS{" "}
                <span className="framechildspan">Solutions</span>
              </p>
              <p className="framechildpar2">
                Our platform is fully equipped with the features you’ll need so
                you never have to worry about speed,security, and support for
                your websites, boost your digital experience with us.
              </p>
            </div>
            <div className="framechiled3">
              <div className="framechildbox1">
                <div className="framechildicon">
                  <img className="fram1" src="Frame1.png" alt="" />
                  <p className="framechildipar10">
                    Real-Time Threat Mitigation
                  </p>
                  <p className="framechildipar2">
                    Automatically detect and neutralize DDoS attacks in
                    real-time.
                  </p>
                </div>
              </div>
              <div className="framechildbox1">
                <div className="framechildicon">
                  <img className="fram1" src="Frame1.png" alt="" />
                  <p className="framechildipar1">Multi-Layered Defense</p>
                  <p className="framechildipar2">
                    Combines network-layer protection (Layer 3/4) and
                    application-layer (Layer 7) security to address all
                    potential attack vectors.
                  </p>
                </div>
              </div>
              <div className="framechildbox1">
                <div className="framechildicon">
                  <img className="fram1" src="Frame1.png" alt="" />
                  <p className="framechildipar1">Scalable Protection</p>
                  <p className="framechildipar2">
                    Seamlessly scale to defend against attacks of any size, from
                    small floods to massive volumetric assaults.
                  </p>
                </div>
              </div>
            </div>
            <button className="btnframe">Know More</button>
          </div>
          <div className="frammain3">
            <div className="framsubpart">
              <div className="framsubpart1">
                <p className="framsubp1">
                  Why You Should <span className="framsubpspan">Trust</span> Us
                </p>
                <p className="framsubp2">
                  Many offer cheap hosting, but why you should trust us?
                </p>
              </div>
              <div className="framsubpart2">
                <div className="framsub3box">
                  <img className="costomer" src="costomer.png" alt="" />
                  <h4 className="customerhead">24x7 Support</h4>
                  <p className="customerpar">
                    Get assistance anytime with our dedicated team, ensuring
                    uninterrupted service for your projects
                  </p>
                </div>
                <div className="framsub3box">
                  <img className="costomer" src="gov.png" alt="" />
                  <h4 className="customerhead">Backed by Indian Government</h4>
                  <p className="customerpar">
                    Benefit from government-backed reliability and compliance,
                    ensuring trust and credibility for your server deployment.
                  </p>
                </div>
                <div className="framsub3box">
                  <img className="costomer" src="refund.png" alt="" />
                  <h4 className="customerhead">Refund Policy</h4>
                  <p className="customerpar">
                    Enjoy peace of mind with our hassle-free 7 days refund
                    policy, prioritizing your satisfaction.
                  </p>
                </div>
              </div>
            </div>
          </div>
          
          <Testimonial />
          
          <div className="framemain5">
            <div className="subfram5">
              <p className="subframpara5">
                Our <span>Trusted</span>{" "}
                <span className="trusted">Partnerships</span>
              </p>
              <div className="minisubfram5">
                <div className="minisubfram1">
                  <img src="f1.png" alt="Partner 1" />
                  <img src="f2.png" alt="Partner 2" />
                  <img src="f3.png" alt="Partner 3" />
                  <img src="f4.png" alt="Partner 4" />
                  <img src="f5.png" alt="Partner 5" />
                  <img src="f6.png" alt="Partner 6" />
                </div>
                <p className="minisubframpar">
                  Collaborating with industry leaders like AWS, Google Cloud,
                  and more than 30 other trusted partners to deliver top-tier
                  solutions.
                </p>
              </div>
            </div>
          </div>
          <div className="frammain6">
            <div className="minifram6">
              <div className="minisubfram7">
                <img className="happy" src="happy.png" alt="" />
                <p className="faq">F.A.Q</p>
              </div>
              <p className="miniframpar7">
                Here Are The Some Common Question About{" "}
                <span className="serve">Serverpie</span>
              </p>
            </div>
            <div className="minifram7">
              <div className="doi">
                <div className="doisub">
                  <p className="doip">
                    Do I need to pay to Instapay even when there is no
                    transaction going on in my business?
                  </p>
                  <button className="doib">
                    <FaPlus className="plus" />
                  </button>
                </div>
              </div>
              <div className="what">
                <div className="subwhat">
                  <p className="whatp">
                    What platforms does Instapay payment gateway support?
                  </p>
                  <button className="doib">
                    <FaPlus className="plus" />
                  </button>
                </div>
              </div>
              <div className="is">
                <div className="subis">
                  <p className="isp">
                    Is there any setup fee or annual maintainance fee that I
                    need to pay regularly?
                  </p>
                  <button className="doib1">
                    <RiSubtractFill className="plus1" />
                  </button>
                </div>
                <p className="need">
                  Do I need to pay to Instapay even when there is no transaction
                  going on in my business?
                </p>
              </div>
              <div className="does">
                <div className="subdoes">
                  <p className="doesp">
                    Does Instapay provide international payments support?
                  </p>
                  <button className="doib">
                    <FaPlus className="plus" />
                  </button>
                </div>
              </div>
            </div>
          </div>
          <div className="frammain8">
            <div className="subframe8">
              <div className="text-container">
                <p className="subframep81">Want to try out our services?????</p>
                <p className="subframp82">
                  Experience premium hosting solutions tailored to your needs.
                  Click on the Try Now button.
                </p>
              </div>
              <button className="subframb81">
                <TbSquareRoundedArrowRightFilled className="tryicon" /> Try Now
              </button>
            </div>
          </div>
          <div className="frammain9">
            <div className="submainfram9">
              <p className="conpar">Contact Our Friendly <span className="team">Team</span></p>
              <p className="letp">Let us know how we can help.</p>
            </div>
              <div className="submainfram92">
                <div className="subbox91">
                  <div className="circle"><PiChatCircleTextFill className="msg" /></div>
                  <p className="livep">Live Chat with Sales</p>
                  <p className="speak">Speak directly to our expert sales team for instant assistance</p>
                  <button className="chat">Chat Now</button>
                </div>
                <div className="subbox91">
                <div className="circle"><FaPhoneVolume className="msg" /></div>
                  <p className="livep">Whatsapp Support</p>
                  <p className="speak">Connect with our friendly support team on WhatsApp for quick help.</p>
                  <button className="chat">Whatsapp</button>
                </div>
                <div className="subbox91">
                <div className="circle"><PiChatsCircleFill className="msg" /></div>
                  <p className="livep">Raise a Support Ticket</p>
                  <p className="speak">Need help? Submit a ticket, and our team will respond promptly.</p>
                  <button className="chat">Raise Ticket</button>
                </div>
                <div className="subbox911">
                <div className="circle1"><FaPhoneVolume className="msg1" /></div>
                  <p className="livep1">Connect on call</p>
                  <p className="speak1">Get in touch with our team directly for assistance over the phone.</p>
                  <button className="chat1">Call Now</button>
                </div>
              </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Home;
