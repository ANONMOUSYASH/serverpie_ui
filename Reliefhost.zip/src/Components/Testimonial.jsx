import React from "react";
import "../Styles/Testimonial.css";
import { IoMdStar } from "react-icons/io";

const Testimonial = () => {
  return (
    <div className="frammain40">
      <div className="frammain4">
        <div className="framsub4">
          <img className="imoges" src="love.png" alt="" />
          <p className="feedback">Feedbacks</p>
          <p className="framsubp4">
            Real Stories, Real Success—Powering Businesses{" "}
            <span className="like">Like Yours</span>{" "}
          </p>
        </div>
        <div className="mainboxy40">
          <div className="framemain41">
            {[...Array(4)].map((_, index) => (
              <div key={index} className="subframbox41">
                <div className="subframbox42">
                  <div className="subframbox43">
                    <img className="yash" src="yash1.jpg" alt="" />
                    <p className="yashpar">yash vardhan</p>
                  </div>
                  <p className="yashpar2">@serverpie</p>
                  <hr className="fullhr" />

                  <div className="subframbox44">
                    <div className="mainstar41">
                      {[...Array(5)].map((_, i) => (
                        <div key={i} className="substar1">
                          <IoMdStar className="iso" />
                        </div>
                      ))}
                    </div>
                    <p className="yeshdate">Jan 28, 2025</p>
                  </div>
                  <div className="subframbox45">
                    <p className="their">Their support is crazy fast and…..</p>
                    <p className="their2">
                      Their support is crazy fast and amazing. Their support is
                      crazy fast and amazing. Their support is crazy fast and
                      amazing.
                    </p>
                  </div>
                  <div className="subbox46">
                    <p className="subboxpar46">
                      Date of experience: January 27, 2025
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
        <div className="subframbox41main">
          {[...Array(4)].map((_, index) => (
            <div key={index} className="subframbox41">
              <div className="subframbox42">
                <div className="subframbox43">
                  <img className="yash" src="yash1.jpg" alt="" />
                  <p className="yashpar">yash vardhan</p>
                </div>
                <p className="yashpar2">@serverpie</p>
                <hr className="fullhr" />

                <div className="subframbox44">
                  <div className="mainstar41">
                    {[...Array(5)].map((_, i) => (
                      <div key={i} className="substar1">
                        <IoMdStar className="iso" />
                      </div>
                    ))}
                  </div>
                  <p className="yeshdate">Jan 28, 2025</p>
                </div>
                <div className="subframbox45">
                  <p className="their">Their support is crazy fast and…..</p>
                  <p className="their2">
                    Their support is crazy fast and amazing. Their support is
                    crazy fast and amazing. Their support is crazy fast and
                    amazing.
                  </p>
                </div>
                <div className="subbox46">
                  <p className="subboxpar46">
                    Date of experience: January 27, 2025
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Testimonial;
