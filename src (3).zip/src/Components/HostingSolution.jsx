import React from 'react'
import '../Styles/HostingSolution.css'
import { BiTimer } from "react-icons/bi";
import { MdUploadFile } from "react-icons/md";
import { FaWordpress } from "react-icons/fa";

const HostingSolution = () => {
  return (
     <div className='hostingsolmain'>
                <div className="hostingsol1">
                    <div className="subattack2 w-[560px] h-[454px]v flex flex-col ">
                        <p className='hostingsolpar1'>We Have a <span className='text-[96px]'>Hosting Solution</span> For You</p>
                        <p className='hostingsolpar2'>ServerPie Shared Hosting – Power, Speed & SecuEnterprise-Grade Processors & Expert Management – Delivering Unmatched Speed, Security, and Reliability for Your Website!rity in One!</p>
                    </div>
                    <div className="subhostingsol3 w-auto h-[654px] flex flex-col gap-[20px]">
                    <div className="subhostingsolsub3 ">
                     <div className="hostingsolbox1 w-[311px] h-[314px] bg-[#ffffff]" style={{borderRadius: "27px"}}>
                            <div className="subhostingsolbox1"><img className='time1' src="time1.png" alt="" /></div>
                                <p className='hostingsolboxpar1'>HACKER-FREE SECURITY</p>
                                <p className='hostingsolboxpar2'>Our security is safe from hackers. It offers strong protection against online threats. This keeps your data secure and ensures that everything runs smoothly. We use the latest defense methods.</p>
                            
                        </div>
                        <div className="hostingsolbox1 w-[311px] h-[314px] bg-[#ffffff]" style={{borderRadius: "27px"}}>
                            <div className="subhostingsolbox1"><img className='time1' src="time2.png" alt="" /></div>
                                <p className='hostingsolboxpar1'>BLAZING FAST SERVERS</p>
                                <p className='hostingsolboxpar2'>Get very fast speeds to improve performance. Enjoy quick loading times and make the website respond better. This will make users feel happier.</p>
                            
                        </div>
                        {/* <div className="hostingsolbox1">
                            <div className="subhostingsolbox1"></div>
                                <p className='hostingsolboxpar1'>HACKER-FREE SECURITY</p>
                                <p className='hostingsolboxpar2'>Our security is safe from hackers. It offers strong protection against online threats. This keeps your data secure and ensures that everything runs smoothly. We use the latest defense methods.</p>
                            
                        </div> */}
                    </div>
                    <div className="subattack4">
                    <div className="subhostingsolsub4 ">
                    <div className="hostingsolbox1 w-[311px] h-[314px] bg-[#ffffff]" style={{borderRadius: "27px"}}>
                            <div className="subhostingsolbox1"><img className='time1' src="time4.png" alt="" /></div>
                                <p className='hostingsolboxpar1'>GLOBAL AVAILABILITY</p>
                                <p className='hostingsolboxpar2'>Whiscloud.com provides hosting services that anyone can use. This means your website will be easy to reach and reliable for people in many places around the globe.</p>
                            
                        </div>
                        <div className="hostingsolbox1 w-[311px] h-[314px] bg-[#ffffff]" style={{borderRadius: "27px"}}>
                            <div className="subhostingsolbox1"><img className='time1' src="time1.png" alt="" /></div>
                                <p className='hostingsolboxpar1'>ENHANCED FILE TRANSFER</p>
                                <p className='hostingsolboxpar2'>Whiscloud.com offers a new SFTP solution. It ensures that your file transfers are secure and simple. The system uses strong encryption to keep your data safe.It also makes sure your data stays reliable and untouched.</p>
                            
                        </div>
                        {/* <div className="hostingsolbox1">
                            <div className="subhostingsolbox1"></div>
                                <p className='hostingsolboxpar1'>HACKER-FREE SECURITY</p>
                                <p className='hostingsolboxpar2'>Our security is safe from hackers. It offers strong protection against online threats. This keeps your data secure and ensures that everything runs smoothly. We use the latest defense methods.</p>
                            
                        </div> */}
                    </div>
                    </div>
                    </div>
                    
                </div>
            </div>
  )
}

export default HostingSolution;
