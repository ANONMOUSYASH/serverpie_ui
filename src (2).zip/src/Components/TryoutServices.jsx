import React from 'react'
import { TbSquareRoundedArrowRightFilled } from "react-icons/tb";
import '../Styles/TryoutServices.css';


const TryoutServices = () => {
  return (
    <div className="frammain8">
    <div className="subframe8">
      <div className="text-container">
        <p className="subframep81">Want to try out our services?</p>
        <p className="subframp82">
          Experience premium hosting solutions tailored to your needs.
          Click on the Try Now button.
        </p>
      </div>
      <button className="subframb81">
        <TbSquareRoundedArrowRightFilled className="tryicon" /> Try Now
      </button>
    </div>
  </div>
  )
}

export default TryoutServices;