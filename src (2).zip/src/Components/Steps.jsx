import React from 'react'
import '../Styles/StepsComp.css'

const Steps = () => {
  return (
    <div className='containermain'>
        <div className="subcontainer">
            <p className='howp'>How It Works</p>
            <p className='top'>To purchase hosting and domain from our portal, follow these steps</p>
        </div>
        <div className="sub2container">
            <div className="sub2box1">
                <div className="sub2box2">
                    <p className='one'>1</p>
                    <hr className='hr5' />
                </div>
                <div className='sub2con1'>
                    <p className='choose'>Choose Right Plan</p>
                    <p className='chhose1'>Choose a suitable hosting plan from</p>
                    <p className='chhose1'>our options based on your budget |</p>
                    <p className='chhose1'>and requirements.</p>
                </div>
            </div>
            <div className="sub2box1">
            <div className="sub2box2">
                    <p className='one'>2</p>
                    <hr className='hr5' />
                </div>
                <div className='sub2con1'>
                    <p className='choose'>Choose Right Plan</p>
                    <p className='chhose1'>Choose a suitable hosting plan from</p>
                    <p className='chhose1'>our options based on your budget |</p>
                    <p className='chhose1'>and requirements.</p>
                </div>
            </div>
            <div className="sub2box1">
            <div className="sub2box2">
                    <p className='one'>3</p>
                    <hr className='hr5' />
                </div>
                <div className='sub2con1'>
                    <p className='choose'>Choose Right Plan</p>
                    <p className='chhose1'>Choose a suitable hosting plan from</p>
                    <p className='chhose1'>our options based on your budget |</p>
                    <p className='chhose1'>and requirements.</p>
                </div>
            </div>
            <div className="sub2box1">
            <div className="sub2box2">
                    <p className='one'>4</p>
                    {/* <hr className='hr5' /> */}
                </div>
                <div className='sub2con1'>
                    <p className='choose'>Choose Right Plan</p>
                    <p className='chhose1'>Choose a suitable hosting plan from</p>
                    <p className='chhose1'>our options based on your budget |</p>
                    <p className='chhose1'>and requirements.</p>
                </div>
            </div>
        </div>
    </div>
  )
}

export default Steps;