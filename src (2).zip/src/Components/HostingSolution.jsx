import React from 'react'
import '../Styles/HostingSolution.css'
import { BiTimer } from "react-icons/bi";
import { MdUploadFile } from "react-icons/md";
import { FaWordpress } from "react-icons/fa";

const HostingSolution = () => {
  return (
     <div className='hostingsolmain'>
                <div className="hostingsol1">
                    <div className="subattack2">
                        <p className='hostingsolpar1'>We Have a Hosting Solution For You</p>
                        <p className='hostingsolpar2'>Why WHISCLOUD Is Best Choice</p>
                    </div>
                    <div className="subhostingsol3">
                    <div className="subhostingsolsub3">
                    <div className="hostingsolbox1">
                            <div className="subhostingsolbox1"></div>
                                <p className='hostingsolboxpar1'>HACKER-FREE SECURITY</p>
                                <p className='hostingsolboxpar2'>Our security is safe from hackers. It offers strong protection against online threats. This keeps your data secure and ensures that everything runs smoothly. We use the latest defense methods.</p>
                            
                        </div>
                        <div className="hostingsolbox1">
                            <div className="subhostingsolbox1"></div>
                                <p className='hostingsolboxpar1'>BLAZING FAST SERVERS</p>
                                <p className='hostingsolboxpar2'>Get very fast speeds to improve performance. Enjoy quick loading times and make the website respond better. This will make users feel happier.</p>
                            
                        </div>
                        <div className="hostingsolbox1">
                            <div className="subhostingsolbox1"></div>
                                <p className='hostingsolboxpar1'>HACKER-FREE SECURITY</p>
                                <p className='hostingsolboxpar2'>Our security is safe from hackers. It offers strong protection against online threats. This keeps your data secure and ensures that everything runs smoothly. We use the latest defense methods.</p>
                            
                        </div>
                    </div>
                    <div className="subattack4">
                    <div className="subhostingsolsub4">
                    <div className="hostingsolbox1">
                            <div className="subhostingsolbox1"></div>
                                <p className='hostingsolboxpar1'>HACKER-FREE SECURITY</p>
                                <p className='hostingsolboxpar2'>Our security is safe from hackers. It offers strong protection against online threats. This keeps your data secure and ensures that everything runs smoothly. We use the latest defense methods.</p>
                            
                        </div>
                        <div className="hostingsolbox1">
                            <div className="subhostingsolbox1"></div>
                                <p className='hostingsolboxpar1'>HACKER-FREE SECURITY</p>
                                <p className='hostingsolboxpar2'>Our security is safe from hackers. It offers strong protection against online threats. This keeps your data secure and ensures that everything runs smoothly. We use the latest defense methods.</p>
                            
                        </div>
                        <div className="hostingsolbox1">
                            <div className="subhostingsolbox1"></div>
                                <p className='hostingsolboxpar1'>HACKER-FREE SECURITY</p>
                                <p className='hostingsolboxpar2'>Our security is safe from hackers. It offers strong protection against online threats. This keeps your data secure and ensures that everything runs smoothly. We use the latest defense methods.</p>
                            
                        </div>
                    </div>
                    </div>
                    </div>
                    
                </div>
            </div>
  )
}

export default HostingSolution;
