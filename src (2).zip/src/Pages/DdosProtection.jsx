import React from 'react'
import Navbar from '../Components/Navbar';
import Footer from '../Components/Footer';
import Attacks from '../Components/Attacks';
import Migration from '../Components/Migration';
import Hostingplans from '../Components/Hostingplans';
import DdosAttacks from '../Components/DdosAttacks';

const DdosProtection = () => {
  return (
    <div>
    <nav>
      {/* <Navbar /> */}
    </nav>
    <main>
    <Attacks />
        <Migration />
        <DdosAttacks />
        {/* Hosting Plans */}
        <Hostingplans />
        {/* Hosting Plans End */}
    </main>
    <footer>
      <Footer />
    </footer>
  </div>
  )
}

export default DdosProtection;
