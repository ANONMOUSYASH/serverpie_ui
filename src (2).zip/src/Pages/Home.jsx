import Footer from "../Components/Footer";
import Navbar from "../Components/Navbar";
import { CiSearch } from "react-icons/ci";
import { IoEarthSharp } from "react-icons/io5";
import { FaPlus } from "react-icons/fa6";
import { RiSubtractFill } from "react-icons/ri";
// import { IoMdStar } from "react-icons/io";
import { FaArrowRight } from "react-icons/fa";
import "../Styles/Home.css";
import Testimonial from "../Components/Testimonial";
import Hosting from "../Components/Hosting";
import Feturelist from "../Components/Feturelist";
import Faq from "../Components/Faq";
import Steps from "../Components/Steps";
import { LuRocket } from "react-icons/lu";
import { MdOutlineSecurity } from "react-icons/md";
import { MdElectricBolt } from "react-icons/md";
import { IoEarthOutline } from "react-icons/io5";
import { AiOutlineBarChart } from "react-icons/ai";
import Serverinfo from "../Components/Serverinfo";
import SeoBanner from "../Components/SeoBanner";
import Contactfriedly from "../Components/Contactfriedly";
import TryoutServices from "../Components/TryoutServices";

const Home = () => {
  return (
    <div>
      <main className="mainclass">
        <div className="hero">
          <p className="heropar1">India's Leading Hosting Provider</p>
          <p className="herohead1">
            Your Dream <span className="herohd">Domain</span> Awaits{" "}
            <span className="herohs">Start Today</span>
            <span className="herohe">!</span>
          </p>
          <p className="heropar2">
            Launch your website today with a domain that works for you!
          </p>

          <div className="heroinput">
            <div className="heroinputsearch">
              <div className="input-container">
                {/* <CiSearch className="herosearch" /> */}
                <input
                  className="heroinput1"
                  type="text"
                  placeholder="ex-demo.com"
                />
              </div>
              {/* <hr className="herohr" /> */}
              <div className="select-container">
                {/* <IoEarthSharp className="heroearth" /> */}
                <select className="heroselect">
                  <option value="com">.com</option>
                  <option value="net">.com</option>
                  <option value="net">.net</option>
                  <option value="org">.org</option>
                  <option value="in">.in</option>
                </select>
              </div>
            </div>
            <hr className="hr1" />
            <div className="sectionherosub">
              <div className="sectionherosub2">
                <p className="startingpar">Starting at</p>
                <p className="dollarp">$4.99</p>
              </div>
              <button className="herobtn">Find My Domain</button>
            </div>
          </div>
          <div className="domainprice">
            <div className="subdomainbox">
              <div className="minidomain">
                <p className="com">.Com</p>
                  <p className="starting">Starting at</p>
                  <div className="subminidomain2">
                  <p className="starting1">$4.99</p>
                  <div className="arrowrightmain"><FaArrowRight className="arrowright" /></div>
                </div>
              </div>
            </div>
            <div className="subdomainbox">
            <div className="minidomain">
                <p className="com">.In</p>
                  <p className="starting">Starting at</p>
                  <div className="subminidomain2">
                  <p className="starting1">$4.99</p>
                  <div className="arrowrightmain"><FaArrowRight className="arrowright" /></div>
                </div>
              </div>
            </div>
            <div className="subdomainbox1">
            <div className="minidomain">
                <p className="com">.Net</p>
                  <p className="starting">Starting at</p>
                  <div className="subminidomain2">
                  <p className="starting1">$4.99</p>
                  <div className="arrowrightmain1"><FaArrowRight className="arrowright1" /></div>
                </div>
              </div>
            </div>
            <div className="subdomainbox">
            <div className="minidomain">
                <p className="com">.Org</p>
                  <p className="starting">Starting at</p>
                  <div className="subminidomain2">
                  <p className="starting1">$4.99</p>
                  <div className="arrowrightmain"><FaArrowRight className="arrowright" /></div>
                </div>
              </div>
            </div>
            <div className="subdomainbox">
            <div className="minidomain">
                <p className="com">.io</p>
                  <p className="starting">Starting at</p>
                  <div className="subminidomain2">
                  <p className="starting1">$4.99</p>
                  <div className="arrowrightmain"><FaArrowRight className="arrowright" /></div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <Steps />
      
        <div className="framemain2">
          <div className="framechild2">
            <p className="framechildpar1">
              Discover Our Advanced Anti-DDoS{" "}
              <span className="framechildspan">Solutions</span>
            </p>
            <p className="framechildpar2">
              Our platform is fully equipped with the features you’ll need so
              you never have to worry about speed,security, and support for
              your websites, boost your digital experience with us.
            </p>
          </div>
          <div className="framechiled3">
            <div className="framechildbox1">
              <div className="framechildicon">
              <LuRocket className="icon22" />
                <p className="framechildipar1">
                Advanced DDoS Protection
                </p>
                <p className="framechildipar2">
                Cutting-edge tech ensures uptime even under
                attack.
                </p>
              </div>
            </div>
            <div className="framechildbox2">
              <div className="framechildicon">
              <MdOutlineSecurity className="icon22" />
                <p className="framechildipar1">Multi-Layered Security</p>
                <p className="framechildipar2">
                Blocks volumetric, protocol, and app-layer
                threats.
                </p>
              </div>
            </div>
            <div className="framechildbox3">
              <div className="framechildicon">
              <MdElectricBolt className="icon22" />
                <p className="framechildipar1">Real-Time Traffic Filtering</p>
                <p className="framechildipar2">
                Instantly detects and mitigates malicious
                traffic.
                </p>
              </div>
            </div>
          </div>
          <div className="framesubmini4box">
          <div className="framechildbox4">
              <div className="framechildicon">
              <IoEarthOutline className="icon22" />
                <p className="framechildipar1">Global Anycast Network</p>
                <p className="framechildipar2">
                Distributed attack absorption for max uptime.
                </p>
              </div>
            </div>
            <div className="framechildbox5">
              <div className="framechildicon">
              <AiOutlineBarChart className="icon22" />
                <p className="framechildipar1">24/7 Monitoring & Alerts</p>
                <p className="framechildipar2">
                Stay informed with real-time analytics and alerts.
                </p>
              </div>
            </div>
          </div>
          
        </div>
         
          {/* Hostig Pricing Boxes */}

          <Hosting />

          <Serverinfo />

          <SeoBanner />

          <div className="heroheadmain2">
          <p className="herohead2">
            From Peak Performance To Non-stop Support, We’ve Got Every Angle
            Covered.
          </p>
          <div className="herorec2">
            <div className="herorec3">
              <button className="herohead4">Performance</button>
            </div>
            <button className="herohead5">Security</button>
            <button className="herohead5">Flexibility</button>
            <button className="herohead5">Scalability</button>
            <button className="herohead5">Support</button>
          </div>
          <div className="heromainbox">
            <div className="herobox1">
              <div className="herosubbox1">
                <div className="herosubearth1">
                  <IoEarthSharp className="herosubearth2" />
                </div>
                <h4 className="heroboxhead1">Faster Load Times</h4>
                <p className="heroboxpar1">
                Reduce latency with optimized servers for a seamless user experience, improving conversions and SEO rankings.
                </p>
              </div>
            </div>
            <div className="herobox2">
              <div className="herosubbox1">
                <div className="herosubearth1">
                  <IoEarthSharp className="herosubearth2" />
                </div>
                <h4 className="heroboxhead2">Instant  Activation</h4>
                <p className="heroboxpar2">
                Launch your projects in minutes with automated provisioning, eliminating downtime.
                </p>
              </div>
            </div>
            <div className="herobox3">
              <div className="herosubbox1">
                <div className="herosubearth1">
                  <IoEarthSharp className="herosubearth2" />
                </div>
                <h4 className="heroboxhead1">High-Performance Architecture</h4>
                <p className="heroboxpar1">
                NVMe SSDs and advanced caching ensure your website runs 10x faster than traditional hosting.
                </p>
              </div>
            </div>
          </div>
        </div>
        {/* Feturelist codebase */}
        {/* <Feturelist /> */}
        {/* Feturelist codebase */}
        <div className="frammain3">
          <div className="framsubpart">
            <div className="framsubpart1">
              <p className="framsubp1">
                Why You Should <span className="framsubpspan">Trust</span> Us
              </p>
              <p className="framsubp2">
                Many offer cheap hosting, but why you should trust us?
              </p>
            </div>
            <div className="framsubpart2">
              <div className="framsub3box">
                <img className="costomer" src="costomer.png" alt="" />
                <h4 className="customerhead">24x7 Support</h4>
                <p className="customerpar">
                  Get assistance anytime with our dedicated team, ensuring
                  uninterrupted service for your projects
                </p>
              </div>
              <div className="framsub3box">
                <img className="costomer" src="gov.png" alt="" />
                <h4 className="customerhead">Backed by Indian Government</h4>
                <p className="customerpar">
                  Benefit from government-backed reliability and compliance,
                  ensuring trust and credibility for your server deployment.
                </p>
              </div>
              <div className="framsub3box">
                <img className="costomer" src="refund.png" alt="" />
                <h4 className="customerhead">Refund Policy</h4>
                <p className="customerpar">
                  Enjoy peace of mind with our hassle-free 7 days refund
                  policy, prioritizing your satisfaction.
                </p>
              </div>
            </div>
          </div>
        </div>

        <Testimonial />

        <div className="framemain5">
          <div className="subfram5">
            <p className="subframpara5">
              Our <span>Trusted</span>{" "}
              <span className="trusted">Partnerships</span>
            </p>
            <div className="minisubfram5">
              <div className="minisubfram1">
                <img src="f1.png" alt="Partner 1" />
                <img src="f2.png" alt="Partner 2" />
                <img src="f3.png" alt="Partner 3" />
                <img src="f4.png" alt="Partner 4" />
                <img src="f5.png" alt="Partner 5" />
                <img src="f6.png" alt="Partner 6" />
              </div>
              <p className="minisubframpar">
                Collaborating with industry leaders like AWS, Google Cloud,
                and more than 30 other trusted partners to deliver top-tier
                solutions.
              </p>
            </div>
          </div>
        </div>
        {/* Faq Com */}
       <Faq />
        {/* Faq Com End*/}

        {/* TryOutServices Com */}
       <TryoutServices />
        {/* TryOutServices Com End*/}

        {/* ContactFriedly Com */}
       <Contactfriedly />
       {/* ContactFriedly Com End*/}
        {/* </div> */}
      </main>
      <Footer />
    </div>
  );
};

export default Home;
