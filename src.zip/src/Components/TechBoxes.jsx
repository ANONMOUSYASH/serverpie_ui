import React from 'react'
import { MdArrowOutward } from "react-icons/md";

const TechBoxes = () => {
  return (
   
    <div className="w-[1251px] h-[234px] flex flex-col gap-[36px] items-center justify-center mx-[auto]">
    <div className="w-[1130px] h-[54px] flex gap-[24px]">
      <div className="w-[auto] h-[54px] flex items-center justify-center gap-[10px] px-[24px] py-[12px] border-[1px] border-[#C5FFDD] rounded-[100px]">
        <p className=" font-bold text-[18px] leading-[30px] tracking-[-0.025em] text-[#0E2954] pt-[15px]" style={{ fontFamily: "'Inter',serif" }}>
          ASP.NET 7
        </p>
        <MdArrowOutward className="w-[16px]h-[16px] text-[#25A75B]"/>
      </div>
      <div className="w-[auto] h-[54px] flex items-center justify-center gap-[10px] px-[24px] py-[12px] border-[1px] border-[#C5FFDD] rounded-[100px]">
        <p className=" font-bold text-[18px] leading-[30px] tracking-[-0.025em] text-[#0E2954] pt-[15px]" style={{ fontFamily: "'Inter',serif" }}>
        cPanel
        </p>
        <MdArrowOutward className="w-[16px]h-[16px] text-[#25A75B]"/>
      </div>
      <div className="w-[auto] h-[54px] flex items-center justify-center gap-[10px] px-[24px] py-[12px] border-[1px] border-[#C5FFDD] rounded-[100px]">
        <p className=" font-bold text-[18px] leading-[30px] tracking-[-0.025em] text-[#0E2954] pt-[15px]" style={{ fontFamily: "'Inter',serif" }}>
        CyberPanel 7
        </p>
        <MdArrowOutward className="w-[16px]h-[16px] text-[#25A75B]"/>
      </div>
      <div className="w-[auto] h-[54px] flex items-center justify-center gap-[10px] px-[24px] py-[12px] border-[1px] border-[#C5FFDD] rounded-[100px]">
        <p className=" font-bold text-[18px] leading-[30px] tracking-[-0.025em] text-[#0E2954] pt-[15px]" style={{ fontFamily: "'Inter',serif" }}>
        DirectAdmin 7
        </p>
        <MdArrowOutward className="w-[16px]h-[16px] text-[#25A75B]"/>
      </div>
      <div className="w-[auto] h-[54px] flex items-center justify-center gap-[10px] px-[24px] py-[12px] border-[1px] border-[#C5FFDD] rounded-[100px]">
        <p className=" font-bold text-[18px] leading-[30px] tracking-[-0.025em] text-[#0E2954] pt-[15px]" style={{ fontFamily: "'Inter',serif" }}>
        Django 7
        </p>
        <MdArrowOutward className="w-[16px]h-[16px] text-[#25A75B]"/>
      </div>
      <div className="w-[auto] h-[54px] flex items-center justify-center gap-[10px] px-[24px] py-[12px] border-[1px] border-[#C5FFDD] rounded-[100px]">
        <p className=" font-bold text-[18px] leading-[30px] tracking-[-0.025em] text-[#0E2954] pt-[15px]" style={{ fontFamily: "'Inter',serif" }}>
        Docker 7
        </p>
        <MdArrowOutward className="w-[16px]h-[16px] text-[#25A75B]"/>
      </div>

    </div>
    <div className="w-[1130px] h-[54px] flex gap-[24px]">
    <div className="w-[auto] h-[54px] flex items-center justify-center gap-[10px] px-[24px] py-[12px] border-[1px] border-[#C5FFDD] rounded-[100px]">
        <p className=" font-bold text-[18px] leading-[30px] tracking-[-0.025em] text-[#0E2954] pt-[15px]" style={{ fontFamily: "'Inter',serif" }}>
        Forex
        </p>
        <MdArrowOutward className="w-[16px]h-[16px] text-[#25A75B]"/>
      </div>
      <div className="w-[auto] h-[54px] flex items-center justify-center gap-[10px] px-[24px] py-[12px] border-[1px] border-[#C5FFDD] rounded-[100px]">
        <p className=" font-bold text-[18px] leading-[30px] tracking-[-0.025em] text-[#0E2954] pt-[15px]" style={{ fontFamily: "'Inter',serif" }}>
        Ghost
        </p>
        <MdArrowOutward className="w-[16px]h-[16px] text-[#25A75B]"/>
      </div>
      <div className="w-[auto] h-[54px] flex items-center justify-center gap-[10px] px-[24px] py-[12px] border-[1px] border-[#C5FFDD] rounded-[100px]">
        <p className=" font-bold text-[18px] leading-[30px] tracking-[-0.025em] text-[#0E2954] pt-[15px]" style={{ fontFamily: "'Inter',serif" }}>
        Jitsi
        </p>
        <MdArrowOutward className="w-[16px]h-[16px] text-[#25A75B]"/>
      </div>
      <div className="w-[auto] h-[54px] flex items-center justify-center gap-[10px] px-[24px] py-[12px] border-[1px] border-[#C5FFDD] rounded-[100px]">
        <p className=" font-bold text-[18px] leading-[30px] tracking-[-0.025em] text-[#0E2954] pt-[15px]" style={{ fontFamily: "'Inter',serif" }}>
        Laravel 
        </p>
        <MdArrowOutward className="w-[16px]h-[16px] text-[#25A75B]"/>
      </div>
      <div className="w-[auto] h-[54px] flex items-center justify-center gap-[10px] px-[24px] py-[12px] border-[1px] border-[#C5FFDD] rounded-[100px]">
        <p className=" font-bold text-[18px] leading-[30px] tracking-[-0.025em] text-[#0E2954] pt-[15px]" style={{ fontFamily: "'Inter',serif" }}>
        Linux 
        </p>
        <MdArrowOutward className="w-[16px]h-[16px] text-[#25A75B]"/>
      </div>
      <div className="w-[auto] h-[54px] flex items-center justify-center gap-[10px] px-[24px] py-[12px] border-[1px] border-[#C5FFDD] rounded-[100px]">
        <p className=" font-bold text-[18px] leading-[30px] tracking-[-0.025em] text-[#0E2954] pt-[15px]" style={{ fontFamily: "'Inter',serif" }}>
        Magento 
        </p>
        <MdArrowOutward className="w-[16px]h-[16px] text-[#25A75B]"/>
      </div>
      <div className="w-[auto] h-[54px] flex items-center justify-center gap-[10px] px-[24px] py-[12px] border-[1px] border-[#C5FFDD] rounded-[100px]">
        <p className=" font-bold text-[18px] leading-[30px] tracking-[-0.025em] text-[#0E2954] pt-[15px]" style={{ fontFamily: "'Inter',serif" }}>
        Moodle 
        </p>
        <MdArrowOutward className="w-[16px]h-[16px] text-[#25A75B]"/>
      </div>

    </div>
    <div className="w-[1130px] h-[54px] flex gap-[24px]">
    <div className="w-[auto] h-[54px] flex items-center justify-center gap-[10px] px-[24px] py-[12px] border-[1px] border-[#C5FFDD] rounded-[100px]">
        <p className=" font-bold text-[18px] leading-[30px] tracking-[-0.025em] text-[#0E2954] pt-[15px]" style={{ fontFamily: "'Inter',serif" }}>
        n8n
        </p>
        <MdArrowOutward className="w-[16px]h-[16px] text-[#25A75B]"/>
      </div>
      <div className="w-[auto] h-[54px] flex items-center justify-center gap-[10px] px-[24px] py-[12px] border-[1px] border-[#C5FFDD] rounded-[100px]">
        <p className=" font-bold text-[18px] leading-[30px] tracking-[-0.025em] text-[#0E2954] pt-[15px]" style={{ fontFamily: "'Inter',serif" }}>
        Nextcloud 
        </p>
        <MdArrowOutward className="w-[16px]h-[16px] text-[#25A75B]"/>
      </div>
      <div className="w-[auto] h-[54px] flex items-center justify-center gap-[10px] px-[24px] py-[12px] border-[1px] border-[#C5FFDD] rounded-[100px]">
        <p className=" font-bold text-[18px] leading-[30px] tracking-[-0.025em] text-[#0E2954] pt-[15px]" style={{ fontFamily: "'Inter',serif" }}>
        Node.js
        </p>
        <MdArrowOutward className="w-[16px]h-[16px] text-[#25A75B]"/>
      </div>
      <div className="w-[auto] h-[54px] flex items-center justify-center gap-[10px] px-[24px] py-[12px] border-[1px] border-[#C5FFDD] rounded-[100px]">
        <p className=" font-bold text-[18px] leading-[30px] tracking-[-0.025em] text-[#0E2954] pt-[15px]" style={{ fontFamily: "'Inter',serif" }}>
        0do 7
        </p>
        <MdArrowOutward className="w-[16px]h-[16px] text-[#25A75B]"/>
      </div>
      <div className="w-[auto] h-[54px] flex items-center justify-center gap-[10px] px-[24px] py-[12px] border-[1px] border-[#C5FFDD] rounded-[100px]">
        <p className=" font-bold text-[18px] leading-[30px] tracking-[-0.025em] text-[#0E2954] pt-[15px]" style={{ fontFamily: "'Inter',serif" }}>
        Plesk
        </p>
        <MdArrowOutward className="w-[16px]h-[16px] text-[#25A75B]"/>
      </div>
      <div className="w-[auto] h-[54px] flex items-center justify-center gap-[10px] px-[24px] py-[12px] border-[1px] border-[#C5FFDD] rounded-[100px]">
        <p className=" font-bold text-[18px] leading-[30px] tracking-[-0.025em] text-[#0E2954] pt-[15px]" style={{ fontFamily: "'Inter',serif" }}>
        Portainer
        </p>
        <MdArrowOutward className="w-[16px]h-[16px] text-[#25A75B]"/>
      </div>
      <div className="w-[auto] h-[54px] flex items-center justify-center gap-[10px] px-[24px] py-[12px] border-[1px] border-[#C5FFDD] rounded-[100px]">
        <p className=" font-bold text-[18px] leading-[30px] tracking-[-0.025em] text-[#0E2954] pt-[15px]" style={{ fontFamily: "'Inter',serif" }}>
        Rails 
        </p>
        <MdArrowOutward className="w-[16px]h-[16px] text-[#25A75B]"/>
      </div>

    </div>
    
  </div>
  
  )
}

export default TechBoxes;