import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import '../Styles/Navbar.css';

const Navbar = () => {
  const [activeIndex, setActiveIndex] = useState(null);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [dropdown, setDropdown] = useState(null);
  const navigate = useNavigate();

  const handleClick = (index, path) => {
    setActiveIndex(index);
    navigate(path);
  };

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const toggleDropdown = (index) => {
    setDropdown(dropdown === index ? null : index);
  };

  return (
    <nav>
      <h1 className="logo">Serverpie</h1>
      <div className={`hamburger ${isMenuOpen ? 'open' : ''}`} onClick={toggleMenu}>
        <div></div>
        <div></div>
        <div></div>
      </div>
      <ul className={`nav1 ${isMenuOpen ? 'show' : ''}`}>
        <li onClick={() => handleClick(0, '/home')}>Home</li>
        
        <li className="dropdown" onMouseEnter={() => toggleDropdown(1)} onMouseLeave={() => toggleDropdown(null)}>Domain
          {dropdown === 1 && (
            <ul className="dropdown-menu">
              <li onClick={() => handleClick(null, '/domain-registration')}>Domain Registration</li>
            </ul>
          )}
        </li>

        <li className="dropdown" onMouseEnter={() => toggleDropdown(2)} onMouseLeave={() => toggleDropdown(null)}>Hosting
          {dropdown === 2 && (
            <ul className="dropdown-menu">
              <li onClick={() => handleClick(null, '/shared-hosting')}>Shared Hosting</li>
              <li onClick={() => handleClick(null, '/dedicated-hosting')}>Dedicated Hosting</li>
              <li onClick={() => handleClick(null, '/wordpress-hosting')}>WordPress Hosting</li>
              <li onClick={() => handleClick(null, '/envato-hosting')}>Envato Hosting</li>
            </ul>
          )}
        </li>
        
        <li className="dropdown" onMouseEnter={() => toggleDropdown(3)} onMouseLeave={() => toggleDropdown(null)}>Server
          {dropdown === 3 && (
            <ul className="dropdown-menu">
              <li onClick={() => handleClick(null, '/vps-server')}>VPS Server</li>
              <li onClick={() => handleClick(null, '/windows-server')}>Windows Server</li>
              <li onClick={() => handleClick(null, '/dedicated-server')}>Dedicated Server</li> 
            </ul>
          )}
        </li>
        
        <li onClick={() => handleClick(4, '/ddos-protection')}>DDOS Protection</li>
        <li onClick={() => handleClick(5, '/contact')}>Contact Us</li>
      </ul>
      <button className="loginbtn" onClick={() => handleClick(null, '/login')}>Login</button>

    </nav>
  );
};

export default Navbar;