import React from 'react'
import Navbar from '../Components/Navbar';
import Footer from '../Components/Footer';

const DdosProtection = () => {
  return (
    <div>
    <nav>
      {/* <Navbar /> */}
    </nav>
    <main></main>
    <footer>
      <Footer />
    </footer>
  </div>
  )
}

export default DdosProtection;
