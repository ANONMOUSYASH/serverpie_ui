import React from 'react'
import Navbar from '../../Components/Navbar';
import Footer from '../../Components/Footer';
import '../../Styles/WordpressHosting.css';
import Hosting from '../../Components/Hosting'
import { MdOutlineArrowForwardIos } from "react-icons/md";
import Faq from '../../Components/Faq';
import TryoutServices from '../../Components/TryoutServices';
import Contactfriedly from '../../Components/Contactfriedly';

const WordpressHosting = () => {
  return (
    <div>
    <nav>
      {/* <Navbar /> */}
    </nav>
    <main>
      {/* Herro Section */}
      <div className="wordpresshero">
        <div className="wordpresshero1">
          <p className="wordpressheropar1">Fast, Secure & Managed
          WordPress Hosting</p>
          <p className="wordpressheropar2">Supercharge your WordPress website with our high-speed, secure, and fully optimized hosting.</p>
        </div>
        <div className="wordpressherobtn">
          <button className="wordpressherobttn1">View Plans</button>
          <button className="wordpressherobtn2">Connect With Expert</button>
        </div>
      </div>
      {/* Hero Section End */}
      {/* Hero Image Section */}
      <div className='wordpressheroimgmain'>
      <div className='wordpressheroimgsub1'>
        <p className="wordpressheroimgpar1">Everything Your WordPress Site Needs for <span className='subwordpressspan'>Success.</span></p>
        <p className="wordpressheroimgpar2">At A2 Hosting, we make WordPress easy and give you access to a variety of tools to get your website up and running in no time.</p>
      </div>
      <div className='wordpressheroimgsub2'>
      <div className='wordpressheroimgsub21'>
        <img src="/heroimg1.png" alt="" className="wprdpressheroimgimg1" />
      </div>
      <div className='wordpressheroimg22'>
        <div className="wordpresssubmini">
        <div className="subwordpressimg">
          <div className="iconwordpress"><MdOutlineArrowForwardIos className='iconwordpress1' /></div>
          <p className='subwordpresspar1'>Out-Of-The-Box Optimized WordPress</p>
        </div>
        <p className='subwordpresspar2'>We pre-configure our WordPress installs with the best speed and security settings with our A2 Optimized plugin.</p>
        <hr className='subwordpresshr'/>
        </div>
        <div className="wordpresssubmini">
        <div className="subwordpressimg">
          <div className="iconwordpress"><MdOutlineArrowForwardIos className='iconwordpress1' /></div>
          <p className='subwordpresspar1'>WooCommerce for WordPress</p>
        </div>
        <p className='subwordpresspar2'>Easily create an online eCommerce store with just a few clicks by adding the WooCommerce plugin to your site.</p>
        
        {/* <hr className='subwordpresshr'/> */}
        </div>
        <div className="wordpresssubmini">
        <div className="subwordpressimg">
          <div className="iconwordpress"><MdOutlineArrowForwardIos className='iconwordpress1' /></div>
          <p className='subwordpresspar1'>TurboHub Control Panel</p>
        </div>
        <p className='subwordpresspar2'>Easily optimize performance, update plugins, and increase security for every A2 Hosting WordPress site you manage with our cutting-edge TurboHub control panel.</p>
        
        <hr className='subwordpresshr'/>
        </div>
        <div className="wordpresssubmini">
        <div className="subwordpressimg">
          <div className="iconwordpress"><MdOutlineArrowForwardIos className='iconwordpress1' /></div>
          <p className='subwordpresspar1'>Need for Speed</p>
        </div>
        <p className='subwordpresspar2'>Our Managed WordPress plans are backed with our Turbo line that offer some serious speed.</p>
        
        <hr className='subwordpresshr'/>
        </div>
      </div>
      </div>
      </div>
      {/* Hero Image Section End */}

      {/* Hosting Plan */}
      <Hosting />
      {/* Hosting Plan End */}

      {/* Boost Component */}
      <div className="boostcompmain">
      <div className="boostcompmain1">
      <div className="boostcompmain2">
        <p className='boostmainpar1'>We help you boost your business</p>
      </div>
      <div className="boostcompmain3">
      <div className="boostcompmain33">
        <div className="boostrecmain"></div>
        <p className="subboostpar2">99.99% Uptime</p>
      </div>
      <div className="boostcompmain33">
        <div className="boostrecmain"></div>
        <p className="subboostpar2">Anoravaily</p>
      </div>
      <div className="boostcompmain33">
        <div className="boostrecmain"></div>
        <p className="subboostpar2">Dedicated Support</p>
      </div>
      <div className="boostcompmain33">
        <div className="boostrecmain"></div>
        <p className="subboostpar2">30-Day Money-Back Guarantee</p>
      </div>
      </div>
      </div>
      </div>
      {/* Boost Component End */}

      {/* Wordpress siter com */}
      <div className="planningcommain">
      <div className="planningcommain1">
      <div className="planningcommain2">
      <div className="planningcommain3"></div>
      <div className="planningcommain4">
        <p className="plaanningcompar1">Planning to create <span className='spanplanningcom1'>WordPress</span> sites?</p>
        <p className="planningcompar2">You can now build WordPress sites in just 1-click.</p>
      </div>
      </div>
      <div className="planningcom5">
        <button className="planningcombtn1">order now</button>
      </div>
      </div>
      </div>
       {/* Wordpress siter com End */}

        {/* Faq Com */}
        <Faq />
        {/* Faq Com End*/}

         {/* TryOutServices Com */}
       <TryoutServices />
        {/* TryOutServices Com End*/}

        {/* ContactFriedly Com */}
       <Contactfriedly />
       {/* ContactFriedly Com End*/}
    </main>
    <footer>
      <Footer />
    </footer>
  </div>
  )
}

export default WordpressHosting;
