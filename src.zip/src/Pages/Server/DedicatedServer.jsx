import React from "react";
import Navbar from "../../Components/Navbar";
import Footer from "../../Components/Footer";
import Migration from "../../Components/Migration";
import TechBoxes from "../../Components/TechBoxes";

const DedicatedServer = () => {
  return (
    <div>
      <nav>{/* <Navbar /> */}</nav>
      <main>
        {/* Hero Start */}
        <div className="w-[1197px] h-[550px] mx-auto flex gap-[82px]">
          <div className="w-[658px] h-[495px] flex flex-col gap-[39px]">
            <div className="w-[658px] h-[334px] flex flex-col gap-[25px]">
              <p  className=" font-normal text-[#2D5087]"
              style={{
                fontFamily: "'Inter',serif",
                fontSize: "12px",
                lineHeight: "15px",
              }}
              >
                Self Managed Dedicated Server Hosting Get high-powered</p>
              <p className="font-bold text-[#0E2954] border-[#00000033]"
              style={{
                fontFamily: "'Poppins',serif",
                fontSize: "64px",
                lineHeight: "68px",
              }}
              >
                Get high-powered Dedicated Server Hosting.</p>
              <p className="w-[530px] font-normal text-[#2D5087]"
               style={{
                fontFamily: "'Inter',serif",
                fontSize: "16px",
                lineHeight: "24px",
              }}
              >
                With Serverpie Dedicated Hosting, whether you use the Website
                Builder or traditional WordPress, you get all the features,
                tools, and guidance you need to build and launch truly
                impressive WordPress websites.
              </p>
            </div>
            <div className="w-[434px] h-[122px] flex flex-col gap-[32px] mt-[15px]">
              <div className="w-[287px] h-[40px] flex gap-[20px]">
                <img src="circle3.png" alt="" />
                <div className="w-[173px] h-[38px] flex flex-col ">
                  <p className="font-bold text-[#0E2954] border-[#00000033]"
                  style={{
                    fontFamily: "'Inter',serif",
                    fontSize: "14px",
                    lineHeight: "17px",
                  }}
                  >
                    +100k</p>
                  <p className="font-normal text-[#2D5087]"
                   style={{
                    fontFamily: "'Inter',serif",
                    fontSize: "14px",
                    lineHeight: "17px",
                    marginTop: "-10px",
                  }}
                  >
                    Hosting Server Worldwide</p>
                </div>
                
              </div>
              <div className="w-[434px] h-[50px] flex gap-[24px]">
                  <button className="w-[194px] h-[50px] rounded-[5px] p-[10px] bg-[#25A75B] font-bold items-center text-[#ffffff]"
                   style={{
                    fontFamily: "'Inter',serif",
                    fontSize: "16px",
                    lineHeight: "18px",
                  }}
                  >
                    Choose a Plan
                    </button>
                    <button className="w-[194px] h-[50px] rounded-[5px] p-[10px] font-bold items-center text-[#25A75B] border-[1px] border-[#25A75B]"
                   style={{
                    fontFamily: "'Inter',serif",
                    fontSize: "16px",
                    lineHeight: "18px",
                  }}
                  >
                   Sign-up Free Trial
                    </button>
                </div>
                
            </div>
          </div>
          <div className="w-[457px] h-[398px] rounded-[24px] bg-[#F6F6F6]"></div>
        </div>
        {/* Hero End */}
        {/* Hero Section 2 */}
          <div className="w-[997px] h-[250px] flex flex-col gap-[32px] mx-auto items-center justify-center">
            <p className="font-bold text-[#0E2954] text-center"
             style={{
              fontFamily: "'Inter',serif",
              fontSize: "32px",
              lineHeight: "39px",
            }}
            >
              Your Choice of <span className="text-[#25A75B]">Operating System</span></p>
              <div className="w-[997px] h-[140px] p-[10px] flex gap-[10px]">
                <div className="w-[182px] h-[120px] rounded-[12px] border-[2px] p-[10px] border-[#CAF3DB]">
                  <img className="mx-auto pt-[10px]" src="icon001.png" alt="" />
                </div>
                <div className="w-[182px] h-[120px] rounded-[12px] border-[2px] p-[10px] border-[#CAF3DB]">
                  <img className="mx-auto pt-[10px]" src="icon002.png" alt="" />
                </div>
                <div className="w-[182px] h-[120px] rounded-[12px] border-[2px] p-[10px] border-[#CAF3DB]">
                  <img className="mx-auto pt-[10px]" src="icon003.png" alt="" />
                </div>
                <div className="w-[182px] h-[120px] rounded-[12px] border-[2px] p-[10px] border-[#CAF3DB]">
                  <img className="mx-auto pt-[10px]" src="icon004.png" alt="" />
                </div>
                <div className="w-[182px] h-[120px] rounded-[12px] border-[2px] p-[10px] border-[#CAF3DB]">
                  <img className="mx-auto pt-[10px]" src="icon005.png" alt="" />
                </div>
              </div>
          </div>
         {/* Hero Section 2 End*/}

          {/* Dedicated Box */}

            <div className="w-[1366px] h-[642px] mx-auto rounded-[33px] p-[57px 67px 57px 67px] flex flex-col gap-[100px] bg-[#173724]">
              <div className="flex flex-col items-center mx-auto pt-[60px]">
              <p className="font-bold text-[#25A75B]"
               style={{
                fontFamily: "'Inter',serif",
                fontSize: "48px",
                lineHeight: "58px",
              }}
              >DEDICATED <span className="text-[#ffffff]">SERVER HARDWARE</span></p>
              <p className="w-[640px] font-normal text-[#ffffff] text-center"
               style={{
                fontFamily: "'Inter',serif",
                fontSize: "14px",
                lineHeight: "20px",
              }}
              >All of our hardware is fully owned and managed by PebbleHost's team, allowing us great flexibility in the services we provide for our Dedicated Servers, and allowing us to ensure the most competitive pricing without compromising on support.</p>
              </div>
              <div className="w-[1176px] h-[169px] flex  gap-[68px] items-center justify-center mx-auto">
                <div className="w-[291px] h-[279px] flex flex-col gap-[16px]">
                  <div className="w-[291px] h-[43px] rounded-[8px] bg-[#234631]">
                    <div className="flex gap-[15px] mx-[10px] p-[10px]">
                      <div className="w-[19px] h-[19px] rounded-[30px] bg-[#25A75B]"></div>
                      <p className="font-inter font-medium text-[12px] leading-[14.52px]  text-white pt-[3px]">INSTANT OS RELOADS</p>
                    </div>
                  </div>
                  <div className="w-[291px] h-[43px] rounded-[8px] bg-[#234631]">
                  <div className="flex gap-[15px] mx-[10px] p-[10px]">
                      <div className="w-[19px] h-[19px] rounded-[30px] bg-[#25A75B]"></div>
                      <p className="font-inter font-medium text-[12px] leading-[14.52px]  text-white pt-[3px]">SUB-USER SYSTEM</p>
                    </div>
                  </div>
                  <div className="w-[291px] h-[43px] rounded-[8px] bg-[#234631]">
                  <div className="flex gap-[15px] mx-[10px] p-[10px]">
                      <div className="w-[19px] h-[19px] rounded-[30px] bg-[#25A75B]"></div>
                      <p className="font-inter font-medium text-[12px] leading-[14.52px]  text-white pt-[3px]">INSTANT OS RELOADS</p>
                    </div>
                  </div>
                  <div className="w-[291px] h-[43px] rounded-[8px] bg-[#234631]">
                  <div className="flex gap-[15px] mx-[10px] p-[10px]">
                      <div className="w-[19px] h-[19px] rounded-[30px] bg-[#25A75B]"></div>
                      <p className="font-inter font-medium text-[12px] leading-[14.52px]  text-white pt-[3px]">ADVANCED LINUX SUPPORT</p>
                    </div>
                  </div>
                  <div className="w-[291px] h-[43px] rounded-[8px] bg-[#234631]">
                  <div className="flex gap-[15px] mx-[10px] p-[10px]">
                      <div className="w-[19px] h-[19px] rounded-[30px] bg-[#25A75B]"></div>
                      <p className="font-inter font-medium text-[12px] leading-[14.52px]  text-white pt-[3px]">REVERSE DNS MANAGEMENT</p>
                    </div>
                  </div>
                </div>


                <div className="w-[291px] h-[279px] flex flex-col gap-[16px] items-center justify-center">
                  <div className="w-[291px] h-[43px] rounded-[8px] bg-[#234631]">
                  <div className="flex gap-[15px] mx-[10px] p-[10px]">
                      <div className="w-[19px] h-[19px] rounded-[30px] bg-[#25A75B]"></div>
                      <p className="font-inter font-medium text-[12px] leading-[14.52px]  text-white pt-[3px]">INSTANT SETUP</p>
                    </div>
                  </div>
                  <div className="w-[291px] h-[43px] rounded-[8px] bg-[#234631]">
                  <div className="flex gap-[15px] mx-[10px] p-[10px]">
                      <div className="w-[19px] h-[19px] rounded-[30px] bg-[#25A75B]"></div>
                      <p className="font-inter font-medium text-[11px] leading-[14px]  text-white pt-[3px]">AVG RESPONSE TIME UNDER 30MIN</p>
                    </div>
                  </div>
                  <div className="w-[291px] h-[43px] rounded-[8px] bg-[#234631]">
                  <div className="flex gap-[15px] mx-[10px] p-[10px]">
                      <div className="w-[19px] h-[19px] rounded-[30px] bg-[#25A75B]"></div>
                      <p className="font-inter font-medium text-[12px] leading-[14.52px]  text-white pt-[3px]">99.99% UPTIME SLA</p>
                    </div>
                  </div>
                  <div className="w-[291px] h-[43px] rounded-[8px] bg-[#234631]">
                  <div className="flex gap-[15px] mx-[10px] p-[10px]">
                      <div className="w-[19px] h-[19px] rounded-[30px] bg-[#25A75B]"></div>
                      <p className="font-inter font-medium text-[12px] leading-[14.52px]  text-white pt-[3px]">FLEXIBLE HARDWARE CONFIGS</p>
                    </div>
                  </div>
                </div>


                <div className="w-[291px] h-[279px] flex flex-col gap-[16px]">
                  <div className="w-[291px] h-[43px] rounded-[8px] bg-[#234631]">
                  <div className="flex gap-[15px] mx-[10px] p-[10px]">
                      <div className="w-[19px] h-[19px] rounded-[30px] bg-[#25A75B]"></div>
                      <p className="font-inter font-medium text-[12px] leading-[14.52px]  text-white pt-[3px]">ACCESS TO KVM & IPMI</p>
                    </div>
                  </div>
                  <div className="w-[291px] h-[43px] rounded-[8px] bg-[#234631]">
                  <div className="flex gap-[15px] mx-[10px] p-[10px]">
                      <div className="w-[19px] h-[19px] rounded-[30px] bg-[#25A75B]"></div>
                      <p className="font-inter font-medium text-[12px] leading-[14.52px]  text-white pt-[3px]">ACCESS TO KVM & IPMI</p>
                    </div>
                  </div>
                  <div className="w-[291px] h-[43px] rounded-[8px] bg-[#234631]">
                  <div className="flex gap-[15px] mx-[10px] p-[10px]">
                      <div className="w-[19px] h-[19px] rounded-[30px] bg-[#25A75B]"></div>
                      <p className="font-inter font-medium text-[12px] leading-[14.52px]  text-white pt-[3px]">US & UK BASED SUPPORT</p>
                    </div>
                  </div>
                  <div className="w-[291px] h-[43px] rounded-[8px] bg-[#234631]">
                  <div className="flex gap-[15px] mx-[10px] p-[10px]">
                      <div className="w-[19px] h-[19px] rounded-[30px] bg-[#25A75B]"></div>
                      <p className="font-inter font-medium text-[12px] leading-[14.52px]  text-white pt-[3px]">FREE BGP PEERING</p>
                    </div>
                  </div>
                  <div className="w-[291px] h-[43px] rounded-[8px] bg-[#234631]">
                  <div className="flex gap-[15px] mx-[10px] p-[10px]">
                      <div className="w-[19px] h-[19px] rounded-[30px] bg-[#25A75B]"></div>
                      <p className="font-inter font-medium text-[12px] leading-[14.52px]  text-white pt-[3px]">GUARANTEED NETWORK SPEED</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

          {/* Dedicated Box End*/}

          {/* Migration Start */}
              <Migration />
          {/* Migration End */}

          {/* Server Featurs */}
              <div className="w-[1440px] h-[511px] mx-auto bg-[#FAFAFA] items-center text-center justify-center p-[50px]">
                <p className="font-inter font-bold text-[48px] leading-[58px] text-[#25A75B] p-[10px]">Server <span className="text-[#000000]">Features</span></p>
                <div className="w-[1219px] h-[260px] flex flex-col gap-[20px] items-center justify-center mx-[50px] pt-[20px]">
                  <div className="w-[1219px] h-[120px] flex gap-[29px] ">
                    <div className="w-[179px] h-[120px] border-[1px] border-[#F3F3F3] rounded-[12px] p-[10px] bg-[#FFFFFF] shadow-[0px_4px_23.5px_0px_#C5C5C540]">
                      <div className="w-[43px] h-[43px] rounded-[38px] bg-[#F1F1F1] items-center mx-[50px]">
                        <img className="p-[10px]" src="server1.png" alt="" />
                      </div>
                      <p className="font-inter font-medium text-[12px] leading-[18px] text-center w-[130px] mx-auto pt-[5px]">DDOS Protection <span className="text-[#25A75B]">(LEARN MORE)</span></p>
                    </div>
                    <div className="w-[179px] h-[120px] border-[1px] border-[#F3F3F3] rounded-[12px] p-[10px] bg-[#FFFFFF] shadow-[0px_4px_23.5px_0px_#C5C5C540]">
                    <div className="w-[43px] h-[43px] rounded-[38px] bg-[#F1F1F1] items-center mx-[50px]">
                    <img className="p-[10px]" src="server2.png" alt="" />
                    </div>
                    <p className="font-inter font-medium text-[12px] leading-[18px] text-center w-[130px] mx-auto pt-[5px]">24/7 UPTIME MONITORING
                    </p>
                    </div>
                    <div className="w-[179px] h-[120px] border-[1px] border-[#F3F3F3] rounded-[12px] p-[10px] bg-[#FFFFFF] shadow-[0px_4px_23.5px_0px_#C5C5C540]">
                    <div className="w-[43px] h-[43px] rounded-[38px] bg-[#F1F1F1] items-center mx-[50px]">
                    <img className="p-[10px]" src="server3.png" alt="" />
                    </div>
                    <p className="font-inter font-medium text-[12px] leading-[18px] text-center w-[130px] mx-auto pt-[5px]">1 gbps Unmetered</p>
                    </div>
                    <div className="w-[179px] h-[120px] border-[1px] border-[#F3F3F3] rounded-[12px] p-[10px] bg-[#FFFFFF] shadow-[0px_4px_23.5px_0px_#C5C5C540]">
                    <div className="w-[43px] h-[43px] rounded-[38px] bg-[#F1F1F1] items-center mx-[50px]">
                    <img className="p-[10px]" src="" alt="" />
                    </div>
                    <p className="font-inter font-medium text-[12px] leading-[18px] text-center w-[130px] mx-auto pt-[5px]">Remote Reboots </p>
                    </div>
                    <div className="w-[179px] h-[120px] border-[1px] border-[#F3F3F3] rounded-[12px] p-[10px] bg-[#FFFFFF] shadow-[0px_4px_23.5px_0px_#C5C5C540]">
                    <div className="w-[43px] h-[43px] rounded-[38px] bg-[#F1F1F1] items-center mx-[50px]">
                    <img className="p-[10px]" src="server4.png" alt="" />
                    </div>
                    <p className="font-inter font-medium text-[12px] leading-[18px] text-center w-[130px] mx-auto pt-[5px]">MANAGED <br /> SUPPORT <br />
                   <span className="text-[#25A75B]">(LEARN MORE)</span></p>
                    </div>
                    <div className="w-[179px] h-[120px] border-[1px] border-[#F3F3F3] rounded-[12px] p-[10px] bg-[#FFFFFF] shadow-[0px_4px_23.5px_0px_#C5C5C540]">
                    <div className="w-[43px] h-[43px] rounded-[38px] bg-[#F1F1F1] items-center mx-[50px]">
                    <img className="p-[10px]" src="server5.png" alt="" />
                    </div>
                    <p className="font-inter font-medium text-[12px] leading-[18px] text-center w-[130px] mx-auto pt-[5px]">ZERO SETUP FEES
                    <span className="text-[#25A75B]">(LEARN MORE)</span></p>
                    </div>
                  </div>

                  <div className="w-[1219px] h-[120px] flex gap-[29px] ">
                    <div className="w-[179px] h-[120px] border-[1px] border-[#F3F3F3] rounded-[12px] p-[10px] bg-[#FFFFFF] shadow-[0px_4px_23.5px_0px_#C5C5C540]">
                    <div className="w-[43px] h-[43px] rounded-[38px] bg-[#F1F1F1] items-center mx-[50px]">
                    <img className="p-[10px]" src="" alt="" />
                    </div>
                    <p className="font-inter font-medium text-[12px] leading-[18px] text-center w-[130px] mx-auto pt-[5px]">24/7 UPTIME MONITORING
                    </p>
                    </div>
                    <div className="w-[179px] h-[120px] border-[1px] border-[#F3F3F3] rounded-[12px] p-[10px] bg-[#FFFFFF] shadow-[0px_4px_23.5px_0px_#C5C5C540]">
                    <div className="w-[43px] h-[43px] rounded-[38px] bg-[#F1F1F1] items-center mx-[50px]"></div>
                    <p className="font-inter font-medium text-[12px] leading-[18px] text-center w-[130px] mx-auto pt-[5px]">Remote KVM  </p>
                    </div>
                    <div className="w-[179px] h-[120px] border-[1px] border-[#F3F3F3] rounded-[12px] p-[10px] bg-[#FFFFFF] shadow-[0px_4px_23.5px_0px_#C5C5C540]">
                    <div className="w-[43px] h-[43px] rounded-[38px] bg-[#F1F1F1] items-center mx-[50px]">
                    <img className="p-[10px]" src="server6.png" alt="" />
                    </div>
                    <p className="font-inter font-medium text-[12px] leading-[18px] text-center w-[130px] mx-auto pt-[5px]">PROVISIONING <br /> Time </p>
                    </div>
                    <div className="w-[179px] h-[120px] border-[1px] border-[#F3F3F3] rounded-[12px] p-[10px] bg-[#FFFFFF] shadow-[0px_4px_23.5px_0px_#C5C5C540]">
                    <div className="w-[43px] h-[43px] rounded-[38px] bg-[#F1F1F1] items-center mx-[50px]">
                    <img className="p-[10px]" src="server7.png" alt="" />
                    </div>
                    <p className="font-inter font-medium text-[12px] leading-[18px] text-center w-[130px] mx-auto pt-[5px]">Floating IPs </p>
                    </div>
                    <div className="w-[179px] h-[120px] border-[1px] border-[#F3F3F3] rounded-[12px] p-[10px] bg-[#FFFFFF] shadow-[0px_4px_23.5px_0px_#C5C5C540]">
                    <div className="w-[43px] h-[43px] rounded-[38px] bg-[#F1F1F1] items-center mx-[50px]">
                    <img className="p-[10px]" src="server8.png" alt="" />
                    </div>
                    <p className="font-inter font-medium text-[12px] leading-[18px] text-center w-[130px] mx-auto pt-[5px]">IPMI Access  </p>
                    </div>
                    <div className="w-[179px] h-[120px] border-[1px] border-[#F3F3F3] rounded-[12px] p-[10px] bg-[#FFFFFF] shadow-[0px_4px_23.5px_0px_#C5C5C540]">
                    <div className="w-[43px] h-[43px] rounded-[38px] bg-[#F1F1F1] items-center mx-[50px]">
                    <img className="p-[10px]" src="server9.png" alt="" />
                    </div>
                    <p className="font-inter font-medium text-[12px] leading-[18px] text-center w-[130px] mx-auto pt-[5px]">Remote OS <br /> Reinstall </p>
                    </div>
                  </div>
                </div>
              </div>
          {/* Server Featurs End*/}

          {/* Boxes 2 */}
          <TechBoxes />
        {/* Boxes 2 End */}

      </main>
      <footer>
        <Footer />
      </footer>
    </div>
  );
};

export default DedicatedServer;
